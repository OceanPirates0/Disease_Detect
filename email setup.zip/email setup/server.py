from flask import Flask, request, render_template
import smtplib

app = Flask(__name__)
@app.route("/")
def index():
    return render_template('index.html')

@app.route("/echo", methods=['POST'])
def echo():
    
    sub = "appointment" 
    sender_email = "oceanp689@gmail.com"
    rec_email = "oceanp689@gmail.com"
    password = "Ocean@123"
    message = """\
Dear Mr Gaurav. 
An appointment has been made for Dr. ___Rajendar___, to see you at your home on: 
Thursday 2 November 2020 between 10.00am and 2pm
It would be helpful if a family member or friend could attend this appointment with 
you. It would also be helpful if you could have with you a list of all your current 
medication (prescribed and over-the-counter) 

Unfortunately due to other patients being seen in your area on the above date a set 
time for the doctor to visit cannot be given, however if you require a set time 
appointment please telephone me on the above number and I will be happy to 
arrange a clinic appointment. 

Yours sincerely,
healthify"""

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, rec_email, message)
    server.quit()
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug='True', port=8080)